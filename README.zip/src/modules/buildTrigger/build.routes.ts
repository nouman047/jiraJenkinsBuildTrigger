import { FastifyInstance } from "fastify";
import { postCommenttoJira, registerBuildOnJenkins } from "./build.controller";

async function buildRoutes(server: FastifyInstance) {

    server.post('/', registerBuildOnJenkins)
    server.post('/comment', postCommenttoJira)
}


export default buildRoutes;